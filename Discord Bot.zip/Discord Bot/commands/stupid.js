module.exports = {
    name: 'stupid',
    description: '',
    guildOnly: true,
    execute(message, args) {
        message.channel.send('No u');
    },
};